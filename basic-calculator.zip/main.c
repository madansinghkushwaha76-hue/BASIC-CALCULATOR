#include <stdio.h>

int main()
{
    int choice;
    float num1, num2, result;

    while (1)
    {
        printf("\n========== BASIC CALCULATOR ==========\n");
        printf("1. Addition\n");
        printf("2. Subtraction\n");
        printf("3. Multiplication\n");
        printf("4. Division\n");
        printf("5. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                printf("Enter two numbers: ");
                scanf("%f%f", &num1, &num2);
                result = num1 + num2;
                printf("Addition = %.2f\n", result);
                break;

            case 2:
                printf("Enter two numbers: ");
                scanf("%f%f", &num1, &num2);
                result = num1 - num2;
                printf("Subtraction = %.2f\n", result);
                break;

            case 3:
                printf("Enter two numbers: ");
                scanf("%f%f", &num1, &num2);
                result = num1 * num2;
                printf("Multiplication = %.2f\n", result);
                break;

            case 4:
                printf("Enter two numbers: ");
                scanf("%f%f", &num1, &num2);

                if(num2 != 0)
                    printf("Division = %.2f\n", num1 / num2);
                else
                    printf("Error! Division by zero is not allowed.\n");
                break;

            case 5:
                printf("Thank You!\n");
                return 0;

            default:
                printf("Invalid Choice!\n");
        }
    }

    return 0;
}