#include <stdio.h>

struct Student
{
    int rollNo;
    char name[50];
    float marks1, marks2, marks3;
    float total, average;
    char grade;
};

int main()
{
    struct Student s;

    printf("========== STUDENT GRADE TRACKER ==========\n");

    printf("Enter Roll Number: ");
    scanf("%d", &s.rollNo);

    printf("Enter Student Name: ");
    scanf(" %[^\n]", s.name);

    printf("Enter Marks of Subject 1: ");
    scanf("%f", &s.marks1);

    printf("Enter Marks of Subject 2: ");
    scanf("%f", &s.marks2);

    printf("Enter Marks of Subject 3: ");
    scanf("%f", &s.marks3);

    s.total = s.marks1 + s.marks2 + s.marks3;
    s.average = s.total / 3;

    if(s.average >= 85)
        s.grade = 'A';
    else if(s.average >= 65)
        s.grade = 'B';
    else if(s.average >= 45)
        s.grade = 'C';
    else if(s.average >= 21)
        s.grade = 'D';
    else
        s.grade = 'F';

    printf("\n\n========== REPORT CARD ==========\n\n");
    printf("Roll Number : %d\n", s.rollNo);
    printf("Student Name: %s\n", s.name);
    printf("Subject 1   : %.2f\n", s.marks1);
    printf("Subject 2   : %.2f\n", s.marks2);
    printf("Subject 3   : %.2f\n", s.marks3);
    printf("Total Marks : %.2f\n", s.total);
    printf("Average     : %.2f\n", s.average);
    printf("Grade       : %c\n", s.grade);

    if(s.grade == 'F')
        printf("Result      : FAIL\n");
    else
        printf("Result      : PASS\n");

    return 0;
}
